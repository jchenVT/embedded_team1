/*
 * arm.h
 *
 *  Created on: Feb 20, 2020
 *      Author: chris
 */

#ifndef ARM_H_
#define ARM_H_

#include <FreeRTOS.h>

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stddef.h>

#include <pthread.h>

#include <ti/drivers/GPIO.h>
#include <ti/drivers/PWM.h>
#include <ti/drivers/timer.h>
#include <ti/drivers/UART.h>

#include "arm_queues.h"
#include "ti_drivers_config.h"

#include <timers.h>

typedef enum debugState {WaitingForAngles, WaitingForAck} dState;
typedef enum armState {Moving, NotMoving} aState;

void *armDebugThread(void *arg0);
void *mainArmThread(void *arg0);
void arm_init();
void  movementCallback();

#endif /* ARM_H_ */
